<?php

define('DB_HOST', 'vvv.dev:3306');

define('DB_USER', 'external');
define('DB_PASSWORD', 'external');


