<?php 
error_reporting(0);
@ini_set('display_errors', 0);
define( 'WP_DEBUG', false );