<?php
/**
 * Output the phpinfo for our setup
 */
phpinfo();

