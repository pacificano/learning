# VVV Log Files

This directory will remain empty until log files are written to by services within the virtual machine.

By default, PHP errors will be logged here in a `php_errors.log` file.